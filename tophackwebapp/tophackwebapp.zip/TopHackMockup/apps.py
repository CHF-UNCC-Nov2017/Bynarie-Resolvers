from django.apps import AppConfig


class TophackmockupConfig(AppConfig):
    name = 'TopHackMockup'
