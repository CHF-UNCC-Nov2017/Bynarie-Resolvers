from django.apps import AppConfig


class MockupConfig(AppConfig):
    name = 'mockup'
